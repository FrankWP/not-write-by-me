#include "syshead.h"

int main()
{
	int n;
	char buf[n];
	return 0;
}
